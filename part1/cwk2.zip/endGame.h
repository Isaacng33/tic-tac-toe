
int winGame( Game *game, char symbol );

int drawGame( Game *game );

